﻿namespace EuNet.Unity
{
    public enum NetViewSyncType
    {
        None = 0,
        PositionAndRotation = 1,
    }
}
