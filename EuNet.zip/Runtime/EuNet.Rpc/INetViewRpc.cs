﻿namespace EuNet.Rpc
{
    // P2p에서 NetView 베이스의 Rpc. 상속받아서 코드생성기를 돌리면 코드가 생성된다
    public interface INetViewRpc
    {
    }
}
