﻿namespace EuNet.Core
{
    public enum LogLevel
    {
        None = 0,
        Error = 1,
        Warning = 2,
        Information = 3,
    }
}
